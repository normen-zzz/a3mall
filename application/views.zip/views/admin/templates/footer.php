<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2018 <div class="bullet"></div>
    </div>
    <div class="footer-right">
        2.3.0
    </div>
</footer>