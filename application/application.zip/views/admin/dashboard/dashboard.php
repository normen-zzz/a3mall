<div class="main-content">
	<section class="section">
		<div class="section-header">
			<h1>Blank Page</h1>
		</div>

		<div class="section-body"></div>
	</section>
</div>