<!DOCTYPE html>
<html lang="en">

<body>
    <div class="container">
        <hr />
        <div class="isi">
            <p style="display: flex; justify-content: center; text-align: center">
                Halo, <?= $name; ?>
            </p>
            <p style="display: flex; justify-content: center; text-align: center">
                Selamat datang di Atiga Mall, anda telah menjadi Business Executive Atigamall
            </p>
        </div>
        <div class="button" style="display: flex; justify-content: center; text-align: center">
            <a href="<?= base_url('Referral') ?>" style="
						background-color: #007bff;
						color: #fff;
						text-decoration: none;
						padding: 14px;
						border-radius: 6px;
					">Ke halaman Referral</a>
        </div>

        <hr />
        <p style="display: flex; justify-content: center; text-align: center">
            Salam Hangat, A3Mall
        </p>
    </div>
</body>

</html>